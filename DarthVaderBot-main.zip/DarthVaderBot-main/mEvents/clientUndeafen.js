module.exports = {
    name: 'clientUndeafen',
	once: false,
    async execute(queue) {
        console.log(`Меня не защитили.`);
    }
}